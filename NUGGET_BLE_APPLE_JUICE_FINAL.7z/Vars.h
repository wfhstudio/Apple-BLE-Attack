#ifndef VARS_H
#define VARS_H

// Buttons
#define up_btn 19   // 13 up button
#define dn_btn 2  // 18 down button
#define lt_btn 4  // 11 left button
#define rt_btn 5   // 12  right button

#endif