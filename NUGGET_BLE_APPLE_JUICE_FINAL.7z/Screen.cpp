#include "Arduino.h"
#include "Screen.h"
#include "SH1106.h"
#include "graphics.h"

SH1106Wire display(0x3C, 21, 22);   //35,36

const char* Screen::sectionText = "BLUETOOTH SPAM"; // Define and initialize sectionText

Screen::Screen() {
sectionText = "BLUETOOTH SPAM";
}

void Screen::initDisplay() {
  display.init();
  display.flipScreenVertically();
  display.setTextAlignment(TEXT_ALIGN_LEFT);
  display.setFont(ArialMT_Plain_10);
}

void Screen::displaySplash(uint8_t sec) {
  display.clear();
  display.drawString(15, 15, "APPLE BLE ATTACK");   //Col .. Row
  display.drawString(60, 35, "@WizzTech");
  display.drawString(15, 35, "Mod.v1.0");
  display.drawString(20, 50, "WorkFromHome 22");
  display.display();
  delay(sec * 2000);
}

void Screen::displayBluetoothOff() {
  display.clear();
  display.drawXbm(0, 0, 128, 64, plain_bits);
  display.drawLine(0, 53, 127, 53);
  display.drawLine(0, 54, 127, 54);
  display.drawString(0, 54, sectionText);
  display.display();
}

void Screen::displayBluetoothOn() {
  display.clear();
  display.drawXbm(0, 0, 128, 64, blue_bits);
  display.drawLine(0, 53, 127, 53);
  display.drawLine(0, 54, 127, 54);
  display.drawString(0, 54, sectionText);
  display.display();
}

void Screen::updateSectionText(const char* newText) {
  sectionText = newText;
  display.setColor(BLACK);
  display.fillRect(0, 55, 128, 9);
  display.setColor(WHITE);

  // Draw the new text in the same location
  display.drawString(0, 54, newText);
  display.display();
}
